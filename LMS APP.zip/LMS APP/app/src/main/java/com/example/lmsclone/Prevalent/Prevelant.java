package com.example.lmsclone.Prevalent;

import com.example.lmsclone.Model.Users;

public class Prevelant
{
    public static Users currentOnlineUser;
//    public static Subjects currentSubject;

    public static final String userUsernameKey = "UserUsername";
    public static final String userPasswordKey = "UserPassword";

//    public static final String currentSubjectName = "CurrentSubjectName";
}
